from __future__ import annotations

from unittest.mock import AsyncMock, patch

import pytest
from textual.widgets import OptionList

from tests.conftest import build_test_vibe_app, build_test_vibe_config, wait_until
from vibe.app_server.config import THINKING_LEVELS
from vibe.app_server.protocol import (
    ConfigFieldKind,
    ConfigFieldsReadResponse,
    ConfigFieldWire,
    ConfigLayerValueWire,
    RuntimeMutationStatus,
)
from vibe.cli.textual_ui.app import BottomApp
from vibe.cli.textual_ui.widgets.context_progress import ContextProgress
from vibe.cli.textual_ui.widgets.messages import ErrorMessage
from vibe.cli.textual_ui.widgets.model_picker import ModelPickerApp
from vibe.cli.textual_ui.widgets.thinking_picker import ThinkingPickerApp
from vibe.core.config import ModelConfig


def _model_configs() -> list[ModelConfig]:
    return [
        ModelConfig(name="model-a", provider="mistral", alias="alpha"),
        ModelConfig(name="model-b", provider="mistral", alias="beta"),
        ModelConfig(name="model-c", provider="mistral", alias="gamma"),
    ]


def _make_config_with_models(**kwargs):
    return build_test_vibe_config(
        models=_model_configs(), active_model="alpha", **kwargs
    )


def _make_unpinned_config(**kwargs):
    # active_model="" is the unpinned/default sentinel.
    return build_test_vibe_config(models=_model_configs(), active_model="", **kwargs)


async def _open_model_picker(pilot, app) -> ModelPickerApp:
    # The picker focuses its option list from a deferred callback, so a key press
    # sent before that lands would reach the chat input instead.
    await app._show_model()
    await wait_until(pilot, lambda: bool(app.query(ModelPickerApp)))
    picker = app.query_one(ModelPickerApp)
    await wait_until(pilot, lambda: picker.query_one(OptionList).has_focus)
    return picker


# --- /model command ---


def test_ui_unpinned_sentinel_matches_schema() -> None:
    # The textual layer keeps its own copy of the sentinel to avoid importing
    # vibe.core (see test_app_server_boundary); guard against value drift so
    # "select Default" always persists a value the schema treats as unpinned.
    from vibe.cli.textual_ui.constants import UNPINNED_ACTIVE_MODEL as ui_value
    from vibe.core.config.vibe_schema import UNPINNED_ACTIVE_MODEL as schema_value

    assert ui_value == schema_value


@pytest.mark.asyncio
async def test_model_opens_model_picker() -> None:
    app = build_test_vibe_app(config=_make_config_with_models())
    async with app.run_test() as pilot:
        await pilot.pause(0.1)
        await _open_model_picker(pilot, app)

        assert app._current_bottom_app == BottomApp.ModelPicker
        assert len(app.query(ModelPickerApp)) == 1


@pytest.mark.asyncio
async def test_model_picker_shows_all_models() -> None:
    app = build_test_vibe_app(config=_make_config_with_models())
    async with app.run_test() as pilot:
        await pilot.pause(0.1)
        await _open_model_picker(pilot, app)

        picker = app.query_one(ModelPickerApp)
        assert [model.alias for model in picker._models] == ["alpha", "beta", "gamma"]
        assert picker._current_model == "alpha"


@pytest.mark.asyncio
async def test_model_picker_shows_display_name_but_persists_alias() -> None:
    models = [
        ModelConfig(name="model-a", provider="mistral", alias="alpha"),
        ModelConfig(
            name="zai-glm-5-2",
            provider="mistral",
            alias="glm-5-2",
            display_name="glm-5.2 (Mistral Hosted)",
        ),
    ]
    config = build_test_vibe_config(models=models, active_model="alpha")
    app = build_test_vibe_app(config=config)
    async with app.run_test() as pilot:
        await pilot.pause(0.1)
        await _open_model_picker(pilot, app)

        picker = app.query_one(ModelPickerApp)
        assert [model.display_name for model in picker._models] == [
            "alpha",
            "glm-5.2 (Mistral Hosted)",
        ]
        option_list = picker.query_one(OptionList)
        # Row 2 is the routed model, offset by the leading Default row.
        assert "glm-5.2 (Mistral Hosted)" in str(
            option_list.get_option_at_index(2).prompt
        )

        # Selecting it still persists the alias, not the label.
        await pilot.press("down")
        await pilot.press("enter")
        await wait_until(pilot, lambda: app.config.active_model.alias == "glm-5-2")

        assert app.config.active_model.alias == "glm-5-2"


@pytest.mark.asyncio
async def test_model_picker_escape_returns_to_input() -> None:
    app = build_test_vibe_app(config=_make_config_with_models())
    async with app.run_test() as pilot:
        await pilot.pause(0.1)
        await _open_model_picker(pilot, app)

        await pilot.press("escape")
        await pilot.pause(0.2)

        assert app._current_bottom_app == BottomApp.Input
        assert len(app.query(ModelPickerApp)) == 0


@pytest.mark.asyncio
async def test_model_picker_escape_does_not_save() -> None:
    app = build_test_vibe_app(config=_make_config_with_models())
    async with app.run_test() as pilot:
        await pilot.pause(0.1)
        await _open_model_picker(pilot, app)

        with patch.object(
            app.app_server.resources.config, "update", new=AsyncMock()
        ) as update_config:
            await pilot.press("escape")
            await pilot.pause(0.2)

            update_config.assert_not_awaited()


@pytest.mark.asyncio
async def test_model_picker_select_model() -> None:
    app = build_test_vibe_app(config=_make_config_with_models())
    async with app.run_test() as pilot:
        await pilot.pause(0.1)
        await _open_model_picker(pilot, app)

        # Navigate down to "beta" and select
        await pilot.press("down")
        await pilot.press("enter")
        await wait_until(pilot, lambda: app.config.active_model.alias == "beta")

        assert app.config.active_model.alias == "beta"
        assert app._current_bottom_app == BottomApp.Input
        assert len(app.query(ModelPickerApp)) == 0


@pytest.mark.asyncio
async def test_model_picker_select_current_model() -> None:
    """Selecting the already-active model still saves (idempotent)."""
    app = build_test_vibe_app(config=_make_config_with_models())
    async with app.run_test() as pilot:
        await pilot.pause(0.1)
        await _open_model_picker(pilot, app)

        await pilot.press("enter")
        await pilot.pause(0.2)

        assert app.config.active_model.alias == "alpha"
        assert app._current_bottom_app == BottomApp.Input


@pytest.mark.asyncio
async def test_model_picker_blocked_when_active_model_enforced() -> None:
    app = build_test_vibe_app(config=_make_config_with_models())
    async with app.run_test(notifications=True) as pilot:
        await pilot.pause(0.1)
        await _open_model_picker(pilot, app)

        enforced_response = ConfigFieldsReadResponse(
            fields=[
                ConfigFieldWire(
                    name="active_model",
                    kind=ConfigFieldKind.ENUM,
                    description="",
                    value="alpha",
                    path="/active_model",
                    layer_values=[ConfigLayerValueWire(layer="admin", value="alpha")],
                )
            ],
            targets=["user-toml"],
        )

        with patch.object(
            app.app_server.resources.config,
            "read_fields",
            new=AsyncMock(return_value=enforced_response),
        ):
            await pilot.press("down")
            await pilot.press("enter")
            await pilot.pause(0.2)

        assert app.config.active_model.alias == "alpha"
        assert app._current_bottom_app == BottomApp.Input
        assert len(app.query(ModelPickerApp)) == 0


@pytest.mark.asyncio
async def test_model_picker_offers_default_row() -> None:
    """A leading Default row precedes the configured models."""
    app = build_test_vibe_app(config=_make_config_with_models())
    async with app.run_test() as pilot:
        await pilot.pause(0.1)
        await _open_model_picker(pilot, app)

        picker = app.query_one(ModelPickerApp)
        option_list = picker.query_one(OptionList)
        # Default + the three configured models.
        assert option_list.option_count == 4
        # A pinned model pre-highlights that model, not the Default row.
        assert picker._is_pinned is True
        assert option_list.highlighted == 1  # "alpha", offset by Default row


@pytest.mark.asyncio
async def test_model_picker_default_row_current_when_unpinned() -> None:
    app = build_test_vibe_app(config=_make_unpinned_config())
    async with app.run_test() as pilot:
        await pilot.pause(0.1)
        await _open_model_picker(pilot, app)

        picker = app.query_one(ModelPickerApp)
        assert picker._is_pinned is False
        # The Default row (index 0) is pre-highlighted for an unpinned user.
        assert picker.query_one(OptionList).highlighted == 0


@pytest.mark.asyncio
async def test_model_picker_select_default_unpins() -> None:
    """Selecting Default from a pinned config clears the pin (persists "")."""
    app = build_test_vibe_app(config=_make_config_with_models())
    async with app.run_test() as pilot:
        await pilot.pause(0.1)
        await _open_model_picker(pilot, app)

        # Highlight starts on pinned "alpha" (index 1); move up to Default.
        await pilot.press("up")
        await pilot.press("enter")
        await wait_until(pilot, lambda: app.config.active_model_pinned is False)

        assert app.config.active_model_pinned is False
        assert app._current_bottom_app == BottomApp.Input
        assert len(app.query(ModelPickerApp)) == 0


@pytest.mark.asyncio
async def test_model_picker_select_default_persists_empty_alias() -> None:
    app = build_test_vibe_app(config=_make_config_with_models())
    async with app.run_test() as pilot:
        await pilot.pause(0.1)
        await _open_model_picker(pilot, app)

        with patch.object(
            app.app_server.resources.config, "write_model", new=AsyncMock()
        ) as write_model:
            await pilot.press("up")
            await pilot.press("enter")
            await wait_until(pilot, lambda: write_model.await_count == 1)

        # The typed pick, not a pointer write: an empty alias is how the picker
        # says "follow the default", and the app-server decides where it lands.
        write_model.assert_awaited_once_with(model_alias="")


@pytest.mark.asyncio
async def test_model_switch_updates_context_window_status_bar() -> None:
    """Switching models refreshes the bottom-bar context window without a restart.

    The bar's max_tokens is the active model's auto_compact_threshold; a switch
    to a model with a different threshold must be reflected immediately.
    """
    models = [
        ModelConfig(
            name="model-a",
            provider="mistral",
            alias="alpha",
            auto_compact_threshold=200_000,
        ),
        ModelConfig(
            name="model-b",
            provider="mistral",
            alias="beta",
            auto_compact_threshold=800_000,
        ),
    ]
    config = build_test_vibe_config(models=models, active_model="alpha")
    app = build_test_vibe_app(config=config)
    async with app.run_test() as pilot:
        await pilot.pause(0.1)
        assert app.query_one(ContextProgress).tokens.max_tokens == 200_000

        await _open_model_picker(pilot, app)
        # Highlight starts on pinned "alpha" (index 1); move down to "beta".
        await pilot.press("down")
        await pilot.press("enter")
        await wait_until(pilot, lambda: app.config.active_model.alias == "beta")

        assert app.query_one(ContextProgress).tokens.max_tokens == 800_000


# --- /thinking command ---


@pytest.mark.asyncio
async def test_thinking_opens_thinking_picker() -> None:
    app = build_test_vibe_app(config=_make_config_with_models())
    async with app.run_test() as pilot:
        await pilot.pause(0.1)
        await app._show_thinking()
        await pilot.pause(0.2)

        assert app._current_bottom_app == BottomApp.ThinkingPicker
        assert len(app.query(ThinkingPickerApp)) == 1


@pytest.mark.asyncio
async def test_thinking_picker_shows_all_levels() -> None:
    app = build_test_vibe_app(config=_make_config_with_models())
    async with app.run_test() as pilot:
        await pilot.pause(0.1)
        await app._show_thinking()
        await pilot.pause(0.2)

        picker = app.query_one(ThinkingPickerApp)
        assert picker._thinking_levels == THINKING_LEVELS
        assert picker._current_thinking == "off"


@pytest.mark.asyncio
async def test_thinking_picker_escape_returns_to_input() -> None:
    app = build_test_vibe_app(config=_make_config_with_models())
    async with app.run_test() as pilot:
        await pilot.pause(0.1)
        await app._show_thinking()
        await pilot.pause(0.2)

        await pilot.press("escape")
        await pilot.pause(0.2)

        assert app._current_bottom_app == BottomApp.Input
        assert len(app.query(ThinkingPickerApp)) == 0


@pytest.mark.asyncio
async def test_thinking_picker_select_level() -> None:
    app = build_test_vibe_app(config=_make_config_with_models())
    async with app.run_test() as pilot:
        await pilot.pause(0.1)
        await app._show_thinking()
        await pilot.pause(0.2)

        # Navigate down to "low" (second item) and select
        await pilot.press("down")
        with (
            patch.object(app, "_reload_config", new=AsyncMock()),
            patch.object(
                app.app_server.resources.config, "set_thinking", new=AsyncMock()
            ) as set_thinking,
        ):
            await pilot.press("enter")
            await pilot.pause(0.2)

        assert app._current_bottom_app == BottomApp.Input
        assert len(app.query(ThinkingPickerApp)) == 0
        set_thinking.assert_awaited_once_with("low")


@pytest.mark.asyncio
async def test_thinking_picker_select_high() -> None:
    app = build_test_vibe_app(config=_make_config_with_models())
    async with app.run_test() as pilot:
        await pilot.pause(0.1)
        await app._show_thinking()
        await pilot.pause(0.2)

        # Navigate to "high" (4th item = 3 downs from "off")
        await pilot.press("down")
        await pilot.press("down")
        await pilot.press("down")
        with (
            patch.object(app, "_reload_config", new=AsyncMock()),
            patch.object(
                app.app_server.resources.config, "set_thinking", new=AsyncMock()
            ) as set_thinking,
        ):
            await pilot.press("enter")
            await pilot.pause(0.2)

        set_thinking.assert_awaited_once_with("high")


@pytest.mark.asyncio
async def test_a_pick_parked_by_a_running_turn_skips_the_reload() -> None:
    """*Prepare*: A model pick the app-server parks until the turn ends.
    *Do*: Select it from the picker.
    *Assert*: No reload follows. ``config/reload`` demands an idle session, so
    running one behind a parked pick answers with a conflict the user reads as
    the pick having failed. It has not: the session announces the pick with
    ``runtime/updated`` once it takes over.
    """
    app = build_test_vibe_app(config=_make_config_with_models())
    async with app.run_test() as pilot:
        await pilot.pause(0.1)
        await _open_model_picker(pilot, app)

        write_model = AsyncMock(return_value=RuntimeMutationStatus.PENDING)
        reload_config = AsyncMock(
            side_effect=AssertionError("A turn is already running")
        )
        with (
            patch.object(
                app.app_server.resources.config, "write_model", new=write_model
            ),
            patch.object(app.app_server.resources.config, "reload", new=reload_config),
        ):
            await pilot.press("down")
            await pilot.press("enter")
            await wait_until(pilot, lambda: write_model.await_count == 1)
            await pilot.pause(0.2)

        assert reload_config.await_count == 0
        assert list(app.query(ErrorMessage)) == []


@pytest.mark.asyncio
async def test_a_thinking_pick_parked_by_a_running_turn_skips_the_reload() -> None:
    """*Prepare*: A thinking level the app-server parks until the turn ends.
    *Do*: Select it from the picker.
    *Assert*: No reload follows, for the same reason a parked model pick runs
    none: both travel on the one write.
    """
    app = build_test_vibe_app(config=_make_config_with_models())
    async with app.run_test() as pilot:
        await pilot.pause(0.1)
        await app._show_thinking()
        await pilot.pause(0.2)

        set_thinking = AsyncMock(return_value=RuntimeMutationStatus.PENDING)
        reload_config = AsyncMock(
            side_effect=AssertionError("A turn is already running")
        )
        with (
            patch.object(
                app.app_server.resources.config, "set_thinking", new=set_thinking
            ),
            patch.object(app.app_server.resources.config, "reload", new=reload_config),
        ):
            await pilot.press("down")
            await pilot.press("enter")
            await wait_until(pilot, lambda: set_thinking.await_count == 1)
            await pilot.pause(0.2)

        assert reload_config.await_count == 0
        assert list(app.query(ErrorMessage)) == []
