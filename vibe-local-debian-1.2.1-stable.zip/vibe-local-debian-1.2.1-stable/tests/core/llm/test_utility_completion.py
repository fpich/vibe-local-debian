from __future__ import annotations

import pytest

from tests.conftest import build_test_vibe_config
from tests.mock.utils import mock_llm_chunk
from tests.stubs.fake_backend import FakeBackend
from vibe.core.config import ModelConfig, ProviderConfig
from vibe.core.llm import utility_completion
from vibe.core.llm.utility_completion import (
    is_fast_utility_model,
    run_utility_completion,
    select_utility_model,
)
from vibe.core.types import Backend


def _anthropic_config():
    return build_test_vibe_config(
        providers=[
            ProviderConfig(
                name="mistral",
                api_base="https://api.mistral.ai/v1",
                api_key_env_var="MISTRAL_API_KEY",
                backend=Backend.MISTRAL,
            ),
            ProviderConfig(
                name="anthropic",
                api_base="https://api.anthropic.com",
                api_key_env_var="ANTHROPIC_API_KEY",
            ),
        ],
        models=[
            ModelConfig(name="claude-test", provider="anthropic", alias="anthropic")
        ],
        active_model="anthropic",
    )


def _anthropic_only_config():
    # A session on Anthropic with no Mistral provider configured at all.
    return build_test_vibe_config(
        providers=[
            ProviderConfig(
                name="anthropic",
                api_base="https://api.anthropic.com",
                api_key_env_var="ANTHROPIC_API_KEY",
            )
        ],
        models=[
            ModelConfig(name="claude-test", provider="anthropic", alias="anthropic")
        ],
        active_model="anthropic",
    )


class TestSelectUtilityModel:
    def test_picks_small_mistral_when_active_provider_mistral(self) -> None:
        model, provider = select_utility_model(build_test_vibe_config())

        assert model.alias == "mistral-small"
        assert provider.name == "mistral"
        assert is_fast_utility_model(build_test_vibe_config())

    def test_prefers_fast_mistral_across_providers_when_available(self) -> None:
        # The session talks to Anthropic, but a Mistral provider is configured and
        # its key resolves: the cheap fast model runs the background nicety rather
        # than the expensive coding model.
        config = _anthropic_config()

        model, provider = select_utility_model(config)

        assert model.alias == "mistral-small"
        assert provider.name == "mistral"
        assert is_fast_utility_model(config)

    def test_falls_back_to_active_when_mistral_key_missing(self, monkeypatch) -> None:
        # Without a resolvable Mistral key the cross-provider route is unusable, so
        # the utility call stays on the session's active model.
        monkeypatch.delenv("MISTRAL_API_KEY", raising=False)
        config = _anthropic_config()

        model, provider = select_utility_model(config)

        assert provider.name == "anthropic"
        assert model.alias == "anthropic"
        assert not is_fast_utility_model(config)

    def test_falls_back_to_active_when_no_mistral_provider(self) -> None:
        config = _anthropic_only_config()

        model, provider = select_utility_model(config)

        assert provider.name == "anthropic"
        assert model.alias == "anthropic"
        assert not is_fast_utility_model(config)

    def test_uses_active_model_when_fast_model_not_allowed(self) -> None:
        config = build_test_vibe_config(
            providers=[
                ProviderConfig(
                    name="mistral",
                    api_base="https://api.mistral.ai/v1",
                    api_key_env_var="MISTRAL_API_KEY",
                )
            ],
            models=[
                ModelConfig(
                    name="mistral-vibe-cli-latest",
                    provider="mistral",
                    alias="devstral-latest",
                )
            ],
            active_model="devstral-latest",
            allowed_models=["mistral-vibe-cli-latest"],
        )

        model, provider = select_utility_model(config)

        assert model.alias == "devstral-latest"
        assert provider.name == "mistral"


class TestRunUtilityCompletion:
    @pytest.mark.asyncio
    async def test_returns_message_content(self, monkeypatch) -> None:
        config = build_test_vibe_config()
        monkeypatch.setattr(
            utility_completion,
            "create_backend",
            lambda **_: FakeBackend([mock_llm_chunk(content="the answer")]),
        )

        content = await run_utility_completion(
            config=config,
            system_prompt="system",
            user_content="user",
            max_tokens=24,
            request_timeout_seconds=1.0,
            retry_budget_seconds=0.0,
        )

        assert content == "the answer"

    @pytest.mark.asyncio
    async def test_forwards_budgets_to_the_backend(self, monkeypatch) -> None:
        config = build_test_vibe_config()
        captured: dict = {}

        def fake_create_backend(**kwargs):
            captured.update(kwargs)
            return FakeBackend([mock_llm_chunk(content="ok")])

        monkeypatch.setattr(utility_completion, "create_backend", fake_create_backend)

        await run_utility_completion(
            config=config,
            system_prompt="system",
            user_content="user",
            max_tokens=24,
            request_timeout_seconds=1.5,
            retry_budget_seconds=7.0,
        )

        assert captured["timeout"] == 1.5
        assert captured["retry_max_elapsed_time"] == 7.0

    @pytest.mark.asyncio
    async def test_propagates_backend_errors(self, monkeypatch) -> None:
        config = build_test_vibe_config()
        monkeypatch.setattr(
            utility_completion,
            "create_backend",
            lambda **_: FakeBackend(exception_to_raise=RuntimeError("boom")),
        )

        with pytest.raises(RuntimeError, match="boom"):
            await run_utility_completion(
                config=config,
                system_prompt="system",
                user_content="user",
                max_tokens=24,
                request_timeout_seconds=1.0,
                retry_budget_seconds=0.0,
            )

    @pytest.mark.asyncio
    async def test_skip_if_no_key_returns_none_without_touching_backend(
        self, monkeypatch
    ) -> None:
        config = build_test_vibe_config()
        monkeypatch.delenv("MISTRAL_API_KEY", raising=False)

        def fail_create_backend(**_):
            raise AssertionError("backend must not be built when the key is missing")

        monkeypatch.setattr(utility_completion, "create_backend", fail_create_backend)

        content = await run_utility_completion(
            config=config,
            system_prompt="system",
            user_content="user",
            max_tokens=24,
            request_timeout_seconds=1.0,
            retry_budget_seconds=0.0,
            skip_if_no_key=True,
        )

        assert content is None

    @pytest.mark.asyncio
    async def test_skip_if_no_key_runs_for_keyless_local_provider(
        self, monkeypatch
    ) -> None:
        # A local provider declares no api_key_env_var; it needs no key, so the
        # skip must not fire even though resolve_api_key("") is always None.
        config = build_test_vibe_config(
            providers=[
                ProviderConfig(
                    name="local",
                    api_base="http://localhost:8080/v1",
                    api_key_env_var="",
                )
            ],
            models=[ModelConfig(name="local-model", provider="local", alias="local")],
            active_model="local",
        )
        monkeypatch.setattr(
            utility_completion,
            "create_backend",
            lambda **_: FakeBackend([mock_llm_chunk(content="named")]),
        )

        content = await run_utility_completion(
            config=config,
            system_prompt="system",
            user_content="user",
            max_tokens=24,
            request_timeout_seconds=1.0,
            retry_budget_seconds=0.0,
            skip_if_no_key=True,
        )

        assert content == "named"

    @pytest.mark.asyncio
    async def test_skip_if_no_key_runs_when_key_present(self, monkeypatch) -> None:
        config = build_test_vibe_config()
        monkeypatch.setenv("MISTRAL_API_KEY", "present")
        monkeypatch.setattr(
            utility_completion,
            "create_backend",
            lambda **_: FakeBackend([mock_llm_chunk(content="named")]),
        )

        content = await run_utility_completion(
            config=config,
            system_prompt="system",
            user_content="user",
            max_tokens=24,
            request_timeout_seconds=1.0,
            retry_budget_seconds=0.0,
            skip_if_no_key=True,
        )

        assert content == "named"


class TestConfiguredUtilityModel:
    def test_configured_utility_model_wins(self) -> None:
        utility = ModelConfig(
            name="worker",
            provider="llamacpp-worker2",
            alias="worker2-utility",
            temperature=0.2,
            thinking="off",
        )
        config = build_test_vibe_config(utility_model=utility)
        providers = [
            *config.providers,
            ProviderConfig(
                name="llamacpp-worker2", api_base="http://127.0.0.1:8081/v1"
            ),
        ]
        config = config.model_copy(update={"providers": providers})
        model, provider = select_utility_model(config)
        assert model.alias == "worker2-utility"
        assert provider.name == "llamacpp-worker2"
        assert is_fast_utility_model(config) is True

    def test_unset_falls_back_to_previous_behavior(self) -> None:
        config = build_test_vibe_config()
        model, _ = select_utility_model(config)
        assert model is not None
